(function(){
"use strict";
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var fmt=function(n){return Math.round(n).toLocaleString("en-PK")};
var pk=function(n){return "PKR "+fmt(n)};
var reduce=window.matchMedia("(prefers-reduced-motion: reduce)").matches;
function toast(m){var t=$("#toast");t.textContent=m;t.classList.add("show");clearTimeout(toast.h);toast.h=setTimeout(function(){t.classList.remove("show")},2600)}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}

/* ---------- sample data (examples only) ---------- */
var PACKAGES=[
 {id:"p1",name:"Dawat Classic",rate:1450,min:60,items:["Chicken qorma","Chicken biryani","Naan","Raita and salad","Kheer"],tag:""},
 {id:"p2",name:"Walima Royal",rate:2200,min:150,items:["Mutton qorma","Chicken biryani","Seekh kabab","Naan","Raita and salad","Gulab jamun","Soft drinks"],tag:"Most booked"},
 {id:"p3",name:"Shahi Baraat",rate:3100,min:250,items:["Mutton karahi","Mutton biryani","Chicken tikka live counter","Roghni naan","Kheer and firni","Tea station","Soft drinks"],tag:""}
];
var ADDONS=[{id:"a0",name:"None",per:0,fixed:0},{id:"a1",name:"Live BBQ counter",per:180,fixed:0},{id:"a2",name:"Tea station",per:60,fixed:0},{id:"a3",name:"Waiters and crockery",per:0,fixed:25000},{id:"a4",name:"Dessert counter",per:120,fixed:0}];
var SERVICES=[
 ["Weddings and baraat","Large buffets for 300 to 1200 guests with live counters and a dedicated service team.","M4 13h16a8 8 0 0 1-16 0z"],
 ["Walima and mehndi","Set menus for the day after and the nights before, priced per head.","M12 3l2.5 5.5L20 9l-4 4 1 6-5-3-5 3 1-6-4-4 5.5-.5z"],
 ["Family dawats","Smaller gatherings from 50 guests, delivered or served at your venue.","M3 11l9-7 9 7v9H3z"],
 ["Corporate and school events","Lunch boxes, seminars and annual dinners with fixed timings.","M4 7h16v12H4zM9 7V4h6v3"],
 ["Religious gatherings","Niaz, milad and iftar catering with simple, quick service.","M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9z"],
 ["Hall and venue option","Choose a listed hall when available, or bring your own venue.","M3 21V8l9-5 9 5v13M9 21v-6h6v6"]];
var EVENT_TYPES=["Wedding / Baraat","Walima","Mehndi / Mayun","Engagement","Birthday","Family dawat","Corporate","School / College","Religious gathering"];
var VENUES=["Own venue (catering only)","Azad Banquet Hall (listed)","Garden Lawn (listed)"];
var CATS=[
 {id:"rice",name:"Rice and biryani",max:2,dishes:[["Chicken biryani",320],["Mutton biryani",480],["Pulao",260],["Zarda",180]]},
 {id:"curry",name:"Main curries",max:2,dishes:[["Chicken qorma",300],["Mutton qorma",460],["Beef qorma",340],["Chicken karahi",380],["Mutton handi",520,true]]},
 {id:"bbq",name:"BBQ and live counter",max:2,dishes:[["Chicken tikka",260],["Malai boti",300],["Seekh kabab",280],["Reshmi kabab",290]]},
 {id:"bread",name:"Breads",max:1,dishes:[["Naan",60],["Roghni naan",80],["Kulcha",70]]},
 {id:"side",name:"Sides",max:2,dishes:[["Raita",40],["Salad",40],["Chutney",20]]},
 {id:"dess",name:"Desserts",max:2,dishes:[["Kheer",120],["Firni",120],["Gulab jamun",110],["Gajar halwa",140]]},
 {id:"drink",name:"Drinks",max:1,dishes:[["Soft drinks",90],["Mineral water",50],["Lassi",110]]}];
var REVIEWS=[
 {n:"Hina Tariq",e:"Walima, 400 guests",r:5,t:"Food came out hot and on time for 400 people. The qorma was the first thing to finish.",v:true},
 {n:"Usman Ghani",e:"Corporate dinner",r:5,t:"Clear quotation, no surprise charges on the day. The staff were organised and quiet.",v:true},
 {n:"Sana Iqbal",e:"Birthday dawat",r:4,t:"Great biryani. Dessert arrived a little late but they apologised and fixed it quickly.",v:true}];

/* ---------- theme & view switching ---------- */
var root=document.documentElement;
$("#themeBtn").addEventListener("click",function(){
  var dark=root.getAttribute("data-theme")==="dark"||(root.getAttribute("data-theme")!=="light"&&matchMedia("(prefers-color-scheme: dark)").matches);
  root.setAttribute("data-theme",dark?"light":"dark");
  if(window.AdminApp)window.AdminApp.redraw();
});
function movePill(){
  var sw=$("#viewSwitch"),b=$('[aria-pressed="true"]',sw),p=$(".pill",sw);
  p.style.left=b.offsetLeft+"px";p.style.width=b.offsetWidth+"px";
}
function show(view){
  $$("#viewSwitch button").forEach(function(b){b.setAttribute("aria-pressed",b.dataset.view===view)});
  $("#v-home").hidden=view!=="home";$("#v-admin").hidden=view!=="admin";
  $("#pubnav").style.visibility=view==="home"?"visible":"hidden";
  movePill();
  var el=$(view==="home"?"#v-home":"#v-admin");el.style.animation="none";el.offsetHeight;el.style.animation="";
  if(view==="admin"&&window.AdminApp)window.AdminApp.enter();
  window.scrollTo(0,0);
}
$$("#viewSwitch button").forEach(function(b){b.addEventListener("click",function(){
  var v=b.dataset.view;try{history.replaceState(null,"","#"+(v==="admin"?"admin":"home"))}catch(e){}show(v)})});
function scrollToId(id){var el=document.getElementById(id);if(el)el.scrollIntoView({behavior:reduce?"auto":"smooth",block:"start"})}
document.addEventListener("click",function(e){
  var a=e.target.closest("[data-go]");if(!a)return;e.preventDefault();
  if($("#v-home").hidden)show("home");
  setTimeout(function(){scrollToId(a.dataset.go)},40);
});
window.addEventListener("resize",movePill);

/* ---------- count-up ---------- */
function countUp(el,to,ms,fmtFn){
  if(reduce){el.textContent=(fmtFn||fmt)(to);return}
  var t0=performance.now();
  (function f(t){var k=Math.min(1,(t-t0)/(ms||1100)),e=1-Math.pow(1-k,3);
    el.textContent=(fmtFn||fmt)(to*e);if(k<1)requestAnimationFrame(f);else el.textContent=(fmtFn||fmt)(to)})(t0);
}
$$("[data-count]").forEach(function(el){countUp(el,+el.dataset.count,1400,function(n){return fmt(n)+"+"})});

/* ---------- public: static sections ---------- */
$("#marq").innerHTML=(["Chicken biryani","Mutton qorma","Seekh kabab","Roghni naan","Kheer","Live tandoor","Gajar halwa","Malai boti"].concat(["Chicken biryani","Mutton qorma","Seekh kabab","Roghni naan","Kheer","Live tandoor","Gajar halwa","Malai boti"])).map(function(s){return "<span>"+s+"</span>"}).join("");
$("#svcGrid").innerHTML=SERVICES.map(function(s,i){return '<div class="svc rise" style="--d:'+(i*.05)+'s"><div class="ic"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="'+s[2]+'"/></svg></div><h3>'+s[0]+'</h3><p>'+s[1]+'</p></div>'}).join("");
$("#pkgGrid").innerHTML=PACKAGES.map(function(p,i){return '<div class="pkg'+(p.tag?" feat":"")+' rise" style="--d:'+(i*.08)+'s">'+(p.tag?'<span class="badge">'+p.tag+'</span>':"")+
 '<h3 style="font-size:22px">'+p.name+'</h3><div class="price mono">'+fmt(p.rate)+' <small>PKR / head · min '+p.min+' guests</small></div><ul>'+p.items.map(function(x){return "<li>"+x+"</li>"}).join("")+'</ul>'+
 '<button class="btn '+(p.tag?"primary":"")+'" data-pick="'+p.id+'" style="margin-top:auto;justify-content:center">Book this package</button></div>'}).join("");
$("#revGrid").innerHTML=REVIEWS.map(function(r){return '<div class="quote"><span class="stars" aria-label="'+r.r+' out of 5">'+"★".repeat(r.r)+"☆".repeat(5-r.r)+'</span><p>'+esc(r.t)+'</p><footer><b>'+esc(r.n)+'</b><span>'+esc(r.e)+(r.v?' · <span class="verified">Verified</span>':"")+'</span></footer></div>'}).join("");

/* ---------- quick estimator (hero) ---------- */
var qePkg=$("#qe-pkg"),qeEx=$("#qe-extra"),qeG=$("#qe-guests");
qePkg.innerHTML=PACKAGES.map(function(p){return '<option value="'+p.id+'">'+p.name+" · "+fmt(p.rate)+" / head</option>"}).join("");
qePkg.value="p2";
qeEx.innerHTML=ADDONS.map(function(a){return '<option value="'+a.id+'">'+a.name+(a.per?" (+"+a.per+" / head)":a.fixed?" (+"+fmt(a.fixed)+")":"")+"</option>"}).join("");
var qeShown=0;
function qe(){
  var p=PACKAGES.filter(function(x){return x.id===qePkg.value})[0],a=ADDONS.filter(function(x){return x.id===qeEx.value})[0],g=+qeG.value;
  $("#qe-gv").textContent=g;
  var total=g*(p.rate+a.per)+a.fixed;
  var el=$("#qe-total"),from=qeShown;qeShown=total;
  if(reduce){el.textContent=fmt(total)}else{var t0=performance.now();(function f(t){var k=Math.min(1,(t-t0)/450),e=1-Math.pow(1-k,3);el.textContent=fmt(from+(total-from)*e);if(k<1)requestAnimationFrame(f)})(t0)}
  $("#qe-per").textContent=fmt(total/g)+" / head";
  var w=g<p.min;$("#qe-per").style.color=w?"var(--saffron-ink)":"";
  $("#qe-per").textContent=w?"Minimum "+p.min+" guests":fmt(total/g)+" / head";
  return total;
}
[qePkg,qeEx,qeG].forEach(function(e){e.addEventListener("input",qe)});
qeShown=0;qe();

/* ---------- custom buffet builder ---------- */
var sel={};CATS.forEach(function(c){sel[c.id]=[]});
sel.rice=["Chicken biryani"];sel.curry=["Chicken qorma"];sel.bread=["Naan"];sel.dess=["Kheer"];
var bG=$("#b-guests");
function price(c,name){return c.dishes.filter(function(d){return d[0]===name})[0][1]}
function renderCats(){
  $("#catList").innerHTML=CATS.map(function(c){
    return '<div class="cat"><h3>'+c.name+'<span>choose up to '+c.max+" · "+sel[c.id].length+" selected</span></h3><div class=\"chips\">"+
    c.dishes.map(function(d){var on=sel[c.id].indexOf(d[0])>-1;
      return '<button class="chip" type="button" data-c="'+c.id+'" data-d="'+esc(d[0])+'" aria-pressed="'+on+'"'+(d[2]?" disabled":"")+'>'+d[0]+(d[2]?" (unavailable)":"")+" <em>+"+d[1]+"</em></button>"}).join("")+"</div></div>"}).join("");
}
function buffet(){
  var g=Math.max(0,+bG.value||0),per=0,lines="";
  CATS.forEach(function(c){sel[c.id].forEach(function(n){var p=price(c,n);per+=p;lines+='<div><span>'+n+'</span><span class="mono">'+p+'</span></div>'})});
  var total=per*g;
  $("#bLines").innerHTML=(lines||'<div><span style="color:var(--ink-3)">No dishes selected yet</span></div>')+
    '<div class="tot"><span>Per head</span><span class="mono">PKR '+fmt(per)+'</span></div><div class="tot" style="border:0;padding:0"><span>'+g+' guests</span><span class="mono">'+pk(total)+'</span></div>';
  var w=[];
  if(g<50)w.push("Minimum 50 guests for a custom buffet.");
  if(!sel.rice.length&&!sel.curry.length)w.push("Add at least one rice or curry dish.");
  $("#bWarn").innerHTML=w.map(function(x){return '<div class="warnbox">'+x+'</div>'}).join("");
  return {per:per,total:total,g:g,count:CATS.reduce(function(s,c){return s+sel[c.id].length},0)};
}
$("#catList").addEventListener("click",function(e){
  var b=e.target.closest(".chip");if(!b||b.disabled)return;
  var c=CATS.filter(function(x){return x.id===b.dataset.c})[0],list=sel[c.id],i=list.indexOf(b.dataset.d);
  if(i>-1)list.splice(i,1);
  else{if(list.length>=c.max){toast("You can pick up to "+c.max+" in "+c.name+".");return}list.push(b.dataset.d)}
  var y=window.scrollY;renderCats();window.scrollTo(0,y);buffet();syncBook();
});
bG.addEventListener("input",function(){buffet();syncBook()});
renderCats();buffet();

/* ---------- booking form ---------- */
var fType=$("#f-type"),fMenu=$("#f-menu"),fVenue=$("#f-venue"),fG=$("#f-guests");
fType.innerHTML=EVENT_TYPES.map(function(t){return "<option>"+t+"</option>"}).join("");
fVenue.innerHTML=VENUES.map(function(t){return "<option>"+t+"</option>"}).join("");
fMenu.innerHTML=PACKAGES.map(function(p){return '<option value="'+p.id+'">'+p.name+"</option>"}).join("")+'<option value="custom">My custom buffet</option>';
function iso(d){var p=function(n){return (n<10?"0":"")+n};return d.getFullYear()+"-"+p(d.getMonth()+1)+"-"+p(d.getDate())}
var d0=new Date();d0.setDate(d0.getDate()+21);$("#f-date").value=iso(d0);$("#f-date").min=iso(new Date());
function bookTotal(){
  var g=+fG.value||0;
  if(fMenu.value==="custom"){return buffet().per*g}
  var p=PACKAGES.filter(function(x){return x.id===fMenu.value})[0];return p.rate*g;
}
function syncBook(){$("#f-est").textContent=pk(bookTotal())}
[fMenu,fG].forEach(function(e){e.addEventListener("input",syncBook)});syncBook();
$("#bUse").addEventListener("click",function(){var b=buffet();fMenu.value="custom";fG.value=b.g;syncBook();toast("Custom buffet added to your booking");scrollToId("book")});
document.addEventListener("click",function(e){var b=e.target.closest("[data-pick]");if(!b)return;fMenu.value=b.dataset.pick;syncBook();scrollToId("book");toast("Package selected")});
window.__newBookings=[];
$("#bookForm").addEventListener("submit",function(e){
  e.preventDefault();
  var name=$("#f-name").value.trim(),ph=$("#f-phone").value.replace(/\s|-/g,""),out=$("#f-result");
  if(!name){out.style.color="var(--crit)";out.textContent="Enter your full name so we know who to call.";$("#f-name").focus();return}
  if(!/^(\+92|0)?3\d{9}$/.test(ph)){out.style.color="var(--crit)";out.textContent="Enter a valid Pakistani mobile number, for example 0300 1234567.";$("#f-phone").focus();return}
  if((+fG.value||0)<20){out.style.color="var(--crit)";out.textContent="Expected guests must be at least 20.";return}
  if($("#bookForm").dataset.busy)return;$("#bookForm").dataset.busy="1";
  var no="AZ-"+(2400+Math.floor(Math.random()*500));
  var mname=fMenu.value==="custom"?"Custom buffet":PACKAGES.filter(function(x){return x.id===fMenu.value})[0].name;
  window.__newBookings.push({no:no,cust:name,phone:ph,type:fType.value,date:$("#f-date").value,guests:+fG.value,venue:fVenue.value,menu:mname,total:bookTotal(),paid:0,status:"pending"});
  out.style.color="var(--good-ink)";out.textContent="Request received. Your reference is "+no+". Status: Pending. We will call you with a quotation.";
  toast("Booking "+no+" submitted");
  if(window.AdminApp)window.AdminApp.refreshNew();
  setTimeout(function(){delete $("#bookForm").dataset.busy},1500);
});
$("#cbForm").addEventListener("submit",function(e){e.preventDefault();var v=$("#cb-phone").value.trim();if(v.length<10){toast("Enter your phone number first");return}toast("Callback requested. We will call you soon.");$("#cb-phone").value=""});
window.__U={$:$,$$:$$,fmt:fmt,pk:pk,esc:esc,toast:toast,countUp:countUp,reduce:reduce,PACKAGES:PACKAGES,CATS:CATS,REVIEWS:REVIEWS,EVENT_TYPES:EVENT_TYPES,VENUES:VENUES,show:show};

/* ================= ADMIN DASHBOARD ================= */
var TODAY=new Date();TODAY.setHours(0,0,0,0);
function dOff(n){var d=new Date(TODAY);d.setDate(d.getDate()+n);return iso(d)}
var DEPOSIT=0.3;
var ST={pending:"Pending",quoted:"Quoted",await:"Awaiting advance",confirmed:"Confirmed",completed:"Completed",cancelled:"Cancelled",rejected:"Rejected"};
var NEXT={pending:["quoted","Send quote"],quoted:["await","Request advance"],await:["confirmed","Record advance and confirm"],confirmed:["completed","Mark completed"]};
var B=[
 {no:"AZ-2391",cust:"Hina Tariq",type:"Walima",date:dOff(-9),guests:400,venue:VENUES[1],menu:"Walima Royal",total:880000,paid:880000,status:"completed"},
 {no:"AZ-2398",cust:"Usman Ghani",type:"Corporate",date:dOff(-3),guests:120,venue:VENUES[0],menu:"Dawat Classic",total:174000,paid:174000,status:"completed"},
 {no:"AZ-2402",cust:"Bilal Ahmad",type:"Wedding / Baraat",date:dOff(4),guests:600,venue:VENUES[1],menu:"Shahi Baraat",total:1860000,paid:558000,status:"confirmed"},
 {no:"AZ-2405",cust:"Rabia Noor",type:"Mehndi / Mayun",date:dOff(4),guests:220,venue:VENUES[1],menu:"Custom buffet",total:640000,paid:0,status:"quoted"},
 {no:"AZ-2409",cust:"Farhan Ali",type:"Family dawat",date:dOff(7),guests:80,venue:VENUES[0],menu:"Dawat Classic",total:116000,paid:0,status:"pending"},
 {no:"AZ-2411",cust:"Maryam Shah",type:"Engagement",date:dOff(11),guests:150,venue:VENUES[2],menu:"Walima Royal",total:330000,paid:99000,status:"confirmed"},
 {no:"AZ-2414",cust:"Imran Khan",type:"Birthday",date:dOff(13),guests:60,venue:VENUES[0],menu:"Dawat Classic",total:87000,paid:0,status:"await"},
 {no:"AZ-2417",cust:"Zainab Malik",type:"Walima",date:dOff(18),guests:350,venue:VENUES[1],menu:"Walima Royal",total:770000,paid:0,status:"pending"},
 {no:"AZ-2420",cust:"Ch. Naveed",type:"Wedding / Baraat",date:dOff(25),guests:900,venue:VENUES[2],menu:"Shahi Baraat",total:2790000,paid:837000,status:"confirmed"},
 {no:"AZ-2388",cust:"Saad Mehmood",type:"Religious gathering",date:dOff(-14),guests:200,venue:VENUES[0],menu:"Dawat Classic",total:290000,paid:0,status:"cancelled"}];
var BLOCKED=[dOff(9),dOff(20)];
var O=[
 {no:"OR-5120",cust:"Aqsa Bibi",items:"Chicken biryani x 10, Raita x 10",ful:"Delivery",total:4200,status:"pending"},
 {no:"OR-5119",cust:"Tahir Mehboob",items:"Dawat Classic x 40",ful:"Pickup",total:58000,status:"accepted"},
 {no:"OR-5118",cust:"School Office, Govt. College",items:"Lunch boxes x 120",ful:"Delivery",total:66000,status:"preparing"},
 {no:"OR-5117",cust:"Noman Raza",items:"Seekh kabab x 30, Naan x 60",ful:"Pickup",total:12000,status:"ready"},
 {no:"OR-5116",cust:"Kinza Fatima",items:"Zarda x 5 kg",ful:"Delivery",total:6500,status:"completed"}];
var ONEXT={pending:["accepted","Accept"],accepted:["preparing","Start preparing"],preparing:["ready","Mark ready"],ready:["completed","Mark delivered"]};
var OST={pending:"Pending",accepted:"Accepted",preparing:"Preparing",ready:"Ready",completed:"Completed"};
var RV=[
 {id:1,n:"Hina Tariq",e:"Walima, 400 guests",r:5,t:REVIEWS[0].t,v:true,s:"approved"},
 {id:2,n:"Usman Ghani",e:"Corporate dinner",r:5,t:REVIEWS[1].t,v:true,s:"approved"},
 {id:3,n:"Sana Iqbal",e:"Birthday dawat",r:4,t:REVIEWS[2].t,v:true,s:"approved"},
 {id:4,n:"Hamza Riaz",e:"Order OR-5110",r:5,t:"Fresh and well packed. Delivery was ten minutes early.",v:true,s:"pending"},
 {id:5,n:"Anonymous",e:"No linked booking",r:1,t:"Never ordered, just testing the form.",v:false,s:"pending"}];
var MONTHS=["Nov","Dec","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct"];
var REV=[2.1,3.6,1.2,0.9,2.4,1.1,0.8,0.6,0.7,0.9,1.9,2.6];
var TYPEC={"Wedding / Baraat":3,"Walima":3,"Family dawat":2,"Corporate":1,"Other":2};

function pay(b){return b.paid<=0?["unpaid","Unpaid"]:b.paid>=b.total?["paid","Paid"]:["partial","Partial"]}
function pill(c,t){return '<span class="st '+c+'">'+t+'</span>'}
function dstr(s){var d=new Date(s+"T00:00:00");return d.toLocaleDateString("en-GB",{day:"2-digit",month:"short"})}
function conflict(b){
  if(b.venue===VENUES[0])return null;
  return B.filter(function(x){return x!==b&&x.date===b.date&&x.venue===b.venue&&(x.status==="confirmed")})[0]||null;
}
function renderRev(){
  var ok=RV.filter(function(r){return r.s==="approved"});
  $("#revGrid").innerHTML=ok.map(function(r){return '<div class="quote"><span class="stars" aria-label="'+r.r+' out of 5">'+"★".repeat(r.r)+"☆".repeat(5-r.r)+'</span><p>'+esc(r.t)+'</p><footer><b>'+esc(r.n)+'</b><span>'+esc(r.e)+(r.v?' · <span class="verified">Verified</span>':"")+'</span></footer></div>'}).join("");
}

var TABS=[["overview","Overview",'<path d="M3 12l9-8 9 8M5 10v10h14V10"/>'],["bookings","Bookings",'<path d="M4 6h16v14H4zM4 10h16M8 3v4M16 3v4"/>'],["orders","Orders",'<path d="M5 7h14l-1 12H6zM9 7a3 3 0 0 1 6 0"/>'],["menu","Menu and packages",'<path d="M4 13h16a8 8 0 0 1-16 0z"/>'],["reviews","Reviews",'<path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.5 6.7 19.4l1.2-6L3.400 9.300l6-.7z"/>']];
var tab="overview",rangeN=12;
function badge(k){
  if(k==="bookings")return B.filter(function(b){return b.status==="pending"}).length;
  if(k==="orders")return O.filter(function(o){return o.status==="pending"}).length;
  if(k==="reviews")return RV.filter(function(r){return r.s==="pending"}).length;return 0}
function side(){
  $("#side").innerHTML=TABS.map(function(t){var n=badge(t[0]);
    return '<button data-tab="'+t[0]+'"'+(t[0]===tab?' aria-current="page"':"")+'><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+t[2]+'</svg>'+t[1]+(n?'<span class="n">'+n+'</span>':"")+'</button>'}).join("")+
    '<hr><button data-tab="site"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/></svg>View website</button>';
}
$("#side").addEventListener("click",function(e){var b=e.target.closest("[data-tab]");if(!b)return;
  if(b.dataset.tab==="site"){show("home");return}tab=b.dataset.tab;draw()});

/* ---------- sparkline & charts ---------- */
function spark(vals,color){
  var w=200,h=34,mx=Math.max.apply(null,vals),mn=Math.min.apply(null,vals),sx=w/(vals.length-1);
  var pts=vals.map(function(v,i){return [i*sx,h-3-((v-mn)/(mx-mn||1))*(h-8)]});
  var d=pts.map(function(p,i){return (i?"L":"M")+p[0].toFixed(1)+" "+p[1].toFixed(1)}).join(" ");
  var last=pts[pts.length-1];
  return '<svg viewBox="0 0 '+w+' '+h+'" preserveAspectRatio="none" aria-hidden="true"><path d="'+d+' L'+w+' '+h+' L0 '+h+'Z" style="fill:'+color+';opacity:.12"/><path d="'+d+'" pathLength="1" class="draw" style="fill:none;stroke:'+color+';stroke-width:2;stroke-linecap:round;stroke-linejoin:round"/></svg>';
}
function revChart(n){
  var data=REV.slice(-n),labs=MONTHS.slice(-n),W=720,H=270,L=44,R=14,T=14,Bm=28;
  var mx=Math.ceil(Math.max.apply(null,data)/1)*1,iw=W-L-R,ih=H-T-Bm;
  var x=function(i){return L+i*iw/(data.length-1)},y=function(v){return T+ih-v/mx*ih};
  var grid="",ticks=4;
  for(var k=0;k<=ticks;k++){var v=mx*k/ticks;grid+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(v)+'" y2="'+y(v)+'" style="stroke:var(--grid);stroke-width:1"/><text x="'+(L-8)+'" y="'+(y(v)+4)+'" text-anchor="end">'+(v%1?v.toFixed(1):v)+'M</text>'}
  var xl="";data.forEach(function(_,i){if(data.length<=7||i%2===(data.length-1)%2)xl+='<text x="'+x(i)+'" y="'+(H-8)+'" text-anchor="middle">'+labs[i]+'</text>'});
  var d=data.map(function(v,i){return (i?"L":"M")+x(i).toFixed(1)+" "+y(v).toFixed(1)}).join(" ");
  var ex=x(data.length-1),ey=y(data[data.length-1]);
  return '<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Monthly revenue in millions of PKR">'+grid+xl+
   '<path d="'+d+' L'+(W-R)+' '+(T+ih)+' L'+L+' '+(T+ih)+'Z" class="area" style="fill:var(--s1);opacity:.14"/>'+
   '<path d="'+d+'" pathLength="1" class="draw" style="fill:none;stroke:var(--s1);stroke-width:2.5;stroke-linejoin:round;stroke-linecap:round"/>'+
   '<circle cx="'+ex+'" cy="'+ey+'" r="5" style="fill:var(--s1);stroke:var(--surface);stroke-width:2"/>'+
   '<text x="'+(ex-8)+'" y="'+(ey-12)+'" text-anchor="end" style="fill:var(--ink);font-weight:700;font-size:12px">'+data[data.length-1]+'M</text>'+
   '<line class="cross" y1="'+T+'" y2="'+(T+ih)+'" style="stroke:var(--line-2);stroke-width:1;opacity:0"/><circle class="hdot" r="5" style="fill:var(--s1);stroke:var(--surface);stroke-width:2;opacity:0"/>'+
   '<rect class="hit" x="'+L+'" y="'+T+'" width="'+iw+'" height="'+ih+'" style="fill:transparent"/></svg><div class="tip" id="rtip"></div>';
}
function wireChart(n){
  var box=$("#revBox");box.innerHTML=revChart(n);
  var data=REV.slice(-n),labs=MONTHS.slice(-n),svg=$("svg",box),hit=$(".hit",svg),cr=$(".cross",svg),hd=$(".hdot",svg),tip=$("#rtip"),W=720,H=270,L=44,R=14,T=14,Bm=28,iw=W-L-R,ih=H-T-Bm,mx=Math.ceil(Math.max.apply(null,data));
  function mv(ev){
    var r=svg.getBoundingClientRect(),px=(ev.clientX-r.left)/r.width*W,i=Math.max(0,Math.min(data.length-1,Math.round((px-L)/iw*(data.length-1))));
    var cx=L+i*iw/(data.length-1),cy=T+ih-data[i]/mx*ih;
    cr.setAttribute("x1",cx);cr.setAttribute("x2",cx);cr.style.opacity=1;hd.setAttribute("cx",cx);hd.setAttribute("cy",cy);hd.style.opacity=1;
    tip.innerHTML="<b>"+labs[i]+"</b>Revenue PKR "+data[i].toFixed(1)+"M";tip.style.opacity=1;
    var tx=cx/W*r.width;tip.style.left=Math.min(r.width-140,Math.max(0,tx-60))+"px";tip.style.top=Math.max(0,cy/H*r.height-62)+"px";
  }
  hit.addEventListener("pointermove",mv);hit.addEventListener("pointerdown",mv);
  hit.addEventListener("pointerleave",function(){cr.style.opacity=0;hd.style.opacity=0;tip.style.opacity=0});
}
function drawAnim(scope){
  if(reduce)return;
  $$(".draw",scope).forEach(function(p){p.style.strokeDasharray="1";p.style.strokeDashoffset="1";p.getBoundingClientRect();p.style.transition="stroke-dashoffset 1.3s cubic-bezier(.3,.8,.2,1)";p.style.strokeDashoffset="0"});
  $$(".area",scope).forEach(function(p){var o=p.style.opacity;p.style.opacity=0;p.style.transition="opacity 1.2s .4s";requestAnimationFrame(function(){p.style.opacity=o})});
}

/* ---------- views ---------- */
var flashNo=null;
function head(t,sub,extra){return '<div class="dh"><div><h2>'+t+'</h2><p>'+sub+'</p></div>'+(extra||"")+'</div>'}
function activeB(){return B.filter(function(b){return b.status!=="cancelled"&&b.status!=="rejected"})}
function upcoming(){return activeB().filter(function(b){return b.date>=dOff(0)&&b.status!=="completed"}).sort(function(a,b){return a.date<b.date?-1:1})}
function kpi(l,id,sub,vals,color){return '<div class="kpi rise"><div class="l">'+l+'</div><div class="v mono" id="'+id+'">0</div><div class="d">'+sub+'</div>'+spark(vals,color)+'</div>'}

function vOverview(){
  var up=upcoming(),pend=B.filter(function(b){return b.status==="pending"}).length;
  var unpaid=activeB().reduce(function(s,b){return s+Math.max(0,b.total-b.paid)},0);
  var cnt={};B.forEach(function(b){cnt[b.menu]=(cnt[b.menu]||0)+1});
  var rows=Object.keys(cnt).sort(function(a,b){return cnt[b]-cnt[a]}),mxc=cnt[rows[0]];
  var cols=["var(--s1)","var(--s2)","var(--s3)"];
  var attn=[];
  B.filter(function(b){return b.status==="pending"}).forEach(function(b){attn.push([b.no+" from "+b.cust+" needs a quotation","var(--saffron)",dstr(b.date)])});
  B.filter(function(b){return b.status==="await"}).forEach(function(b){attn.push([b.no+" is waiting for the advance of "+pk(b.total*DEPOSIT),"var(--s2)",dstr(b.date)])});
  B.forEach(function(b){if(b.status!=="cancelled"&&b.status!=="rejected"&&b.status!=="confirmed"&&b.status!=="completed"&&conflict(b))attn.push([b.no+" overlaps a confirmed booking at "+b.venue,"var(--crit)",dstr(b.date)])});
  var h=head("Overview","Today, "+TODAY.toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"})+" · Sample data for demonstration",
    '<button class="btn primary sm" data-tab-go="bookings">Review requests</button>')+
  '<div class="kpis">'+
    kpi("Upcoming events","k1","Next 25 days, confirmed or in progress",[3,2,4,3,5,4,6,5,7],"var(--s1)")+
    kpi("Pending requests","k2","Waiting for a quotation",[1,2,1,3,2,2,3,2,2],"var(--s2)")+
    kpi("Unpaid balance","k3","Across open bookings (PKR)",[5,4,6,5,7,8,7,9,8],"var(--s3)")+
    kpi("Revenue this month","k4","Up 37% on September",[0.9,0.7,1.9,2.6].concat([]),"var(--s1)")+
  '</div>'+
  '<div class="row2"><div class="panel"><h3>Revenue<span class="seg" role="group" aria-label="Range"><button data-rng="6" aria-pressed="'+(rangeN===6)+'">6 months</button><button data-rng="12" aria-pressed="'+(rangeN===12)+'">12 months</button></span></h3>'+
    '<div class="chartbox" id="revBox"></div><p class="note">PKR millions. Wedding season peaks in winter; summer is the quiet period.</p></div>'+
  '<div class="panel"><h3>Package popularity<small>bookings</small></h3><div class="hbar">'+
   rows.map(function(k,i){return '<div class="r"><span>'+esc(k)+'</span><div class="tr"><div class="fi" data-w="'+(cnt[k]/mxc*100)+'" style="background:'+cols[i%3]+'"></div></div><b class="mono">'+cnt[k]+'</b></div>'}).join("")+
  '</div></div></div>'+
  '<div class="row2 eq"><div class="panel"><h3>Upcoming events<small>next 5</small></h3><ul class="feed">'+
   up.slice(0,5).map(function(b){var c=conflict(b)&&b.status!=="confirmed";return '<li><i style="background:'+(b.status==="confirmed"?"var(--good)":"var(--saffron)")+'"></i><div><b>'+esc(b.cust)+'</b> · '+esc(b.type)+', '+b.guests+' guests<br><small>'+esc(b.venue)+'</small></div><small class="mono">'+dstr(b.date)+'</small></li>'}).join("")+'</ul></div>'+
  '<div class="panel"><h3>Needs attention<small>'+attn.length+' items</small></h3><ul class="feed">'+
   (attn.length?attn.map(function(a){return '<li><i style="background:'+a[1]+'"></i><div>'+esc(a[0])+'</div><small class="mono">'+a[2]+'</small></li>'}).join(""):'<li><i></i><div>Nothing is waiting on you.</div><small></small></li>')+'</ul></div></div>';
  return h;
}
function afterOverview(){
  countUp($("#k1"),upcoming().length,900);countUp($("#k2"),B.filter(function(b){return b.status==="pending"}).length,700);
  var un=activeB().reduce(function(s,b){return s+Math.max(0,b.total-b.paid)},0);
  countUp($("#k3"),un/1e6,1100,function(n){return n.toFixed(2)+"M"});
  countUp($("#k4"),REV[REV.length-1],1100,function(n){return n.toFixed(1)+"M"});
  wireChart(rangeN);drawAnim($("#adminMain"));
  setTimeout(function(){$$(".fi").forEach(function(e){e.style.width=e.dataset.w+"%"})},60);
}

function calHtml(){
  var st=new Date(TODAY);st.setDate(st.getDate()-9);st.setDate(st.getDate()-((st.getDay()+6)%7));var html="";
  ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].forEach(function(d){html+='<div class="dow">'+d+'</div>'});
  for(var k=0;k<35;k++){
    var cd=new Date(st);cd.setDate(st.getDate()+k);var d=cd.getDate();
    var ds=iso(cd),ev=B.filter(function(b){return b.date===ds&&b.status!=="cancelled"&&b.status!=="rejected"});
    var isT=ds===dOff(0);
    html+='<div class="day'+(isT?" today":"")+'"><b>'+(d===1?cd.toLocaleDateString("en-GB",{month:"short"})+" ":"")+d+'</b>'+ev.map(function(b){var ok=b.status==="confirmed"||b.status==="completed";return '<span class="ev" title="'+esc(b.no+" "+b.cust+" ("+ST[b.status]+")")+'" style="background:'+(ok?"var(--brand)":"var(--saffron)")+';color:'+(ok?"var(--brand-ink)":"var(--saffron-ink)")+'">'+esc(b.cust.split(" ")[0])+'</span>'}).join("")+(BLOCKED.indexOf(ds)>-1?'<span class="ev blocked">Blocked</span>':"")+'</div>';
  }
  return html;
}
var bq="",bs="all";
function bRows(){
  return B.filter(function(b){return (bs==="all"||b.status===bs)&&(!bq||(b.cust+b.no+b.type).toLowerCase().indexOf(bq)>-1)}).sort(function(a,b){return a.date<b.date?1:-1}).map(function(b){
    var p=pay(b),n=NEXT[b.status],cn=conflict(b)&&!/confirmed|completed|cancelled|rejected/.test(b.status);
    return '<tr'+(flashNo===b.no?' class="flash"':"")+'><td class="mono">'+b.no+'</td><td><b>'+esc(b.cust)+'</b><br><span style="color:var(--ink-3);font-size:12px">'+esc(b.type)+' · '+b.guests+' guests</span></td><td class="mono">'+dstr(b.date)+'</td><td>'+esc(b.venue.replace(" (listed)",""))+(cn?'<br><span style="color:var(--crit);font-size:12px;font-weight:700">Overlap</span>':"")+'</td><td class="mono">'+fmt(b.total)+'</td><td>'+pill(p[0],p[1])+'<div class="mono" style="font-size:11px;color:var(--ink-3);margin-top:3px">bal '+fmt(Math.max(0,b.total-b.paid))+'</div></td><td>'+pill(b.status,ST[b.status])+'</td><td style="white-space:nowrap">'+
    (n?'<button class="btn sm primary" data-b="'+b.no+'" data-act="adv">'+n[1]+'</button> ':"")+
    (b.status==="pending"?'<button class="btn sm ghost" data-b="'+b.no+'" data-act="rej">Reject</button>':(NEXT[b.status]?'<button class="btn sm ghost" data-b="'+b.no+'" data-act="can">Cancel</button>':""))+'</td></tr>'}).join("")||'<tr><td colspan="8" style="color:var(--ink-3);padding:24px">No bookings match this filter.</td></tr>';
}
function vBookings(){
  return head("Bookings","Quotation, advance and confirmation workflow. Deposit is "+(DEPOSIT*100)+"% (configurable).",'<span class="tag">Today is '+dstr(dOff(0))+'</span>')+
  '<div class="panel" style="margin-bottom:14px"><h3>Calendar, next five weeks<small><span style="color:var(--brand)">■</span> Confirmed &nbsp;<span style="color:var(--saffron)">■</span> Awaiting action &nbsp;<span style="color:var(--ink-3)">■</span> Blocked</small></h3><div class="cal">'+calHtml()+'</div></div>'+
  '<div class="panel"><div class="toolbar"><input id="bsearch" placeholder="Search name, booking number or event" aria-label="Search bookings" value="'+esc(bq)+'"><select id="bstatus" aria-label="Filter by status"><option value="all">All statuses</option>'+Object.keys(ST).map(function(k){return '<option value="'+k+'"'+(bs===k?" selected":"")+'>'+ST[k]+'</option>'}).join("")+'</select></div>'+
  '<div class="tablewrap"><table><thead><tr><th>No.</th><th>Customer</th><th>Date</th><th>Venue</th><th>Total PKR</th><th>Payment</th><th>Status</th><th>Actions</th></tr></thead><tbody id="btbody">'+bRows()+'</tbody></table></div></div>';
}
function oRows(){return O.map(function(o){var n=ONEXT[o.status];return '<tr'+(flashNo===o.no?' class="flash"':"")+'><td class="mono">'+o.no+'</td><td><b>'+esc(o.cust)+'</b></td><td>'+esc(o.items)+'</td><td>'+o.ful+'</td><td class="mono">'+fmt(o.total)+'</td><td>'+pill(o.status==="ready"?"ready":o.status,OST[o.status])+'</td><td>'+(n?'<button class="btn sm primary" data-o="'+o.no+'" data-act="oadv">'+n[1]+'</button>':"")+'</td></tr>'}).join("")}
function vOrders(){
  return head("Orders","Food and catering orders for delivery or pickup. Each step is logged in the history.")+
  '<div class="panel"><div class="tablewrap"><table><thead><tr><th>No.</th><th>Customer</th><th>Items</th><th>Type</th><th>Total PKR</th><th>Status</th><th>Next step</th></tr></thead><tbody>'+oRows()+'</tbody></table></div></div>';
}
function vMenu(){
  var flat=[];CATS.forEach(function(c){c.dishes.forEach(function(d){flat.push({c:c.name,d:d})})});
  return head("Menu and packages","Turn dishes on or off. Unavailable dishes disappear from the customer buffet builder straight away.")+
  '<div class="row2"><div class="panel"><h3>Dishes<small>'+flat.length+' items · price per head, PKR</small></h3><div class="tablewrap"><table><thead><tr><th>Dish</th><th>Category</th><th>Price</th><th>Available</th></tr></thead><tbody>'+
  flat.map(function(x,i){var on=!x.d[2];return '<tr><td><b>'+x.d[0]+'</b></td><td>'+x.c+'</td><td class="mono">'+x.d[1]+'</td><td><button class="switch2" role="switch" aria-checked="'+on+'" aria-label="'+x.d[0]+' available" data-dish="'+i+'"></button></td></tr>'}).join("")+'</tbody></table></div></div>'+
  '<div class="panel"><h3>Packages</h3><div class="hbar" style="gap:16px">'+PACKAGES.map(function(p){return '<div><b>'+p.name+'</b> <span class="tag">min '+p.min+' guests</span><div class="mono" style="font-size:22px;font-family:var(--f-display);font-weight:800;margin-top:4px">PKR '+fmt(p.rate)+' <small style="font-size:12px;color:var(--ink-3);font-family:var(--f-body);font-weight:500">per head</small></div><div style="font-size:12px;color:var(--ink-3)">'+p.items.join(", ")+'</div></div>'}).join("")+'</div></div></div>';
}
function vReviews(){
  return head("Reviews","Approve or hide reviews before they appear on the public website.")+
  '<div class="panel"><div class="tablewrap"><table><thead><tr><th>Customer</th><th>Rating</th><th>Review</th><th>Status</th><th>Moderate</th></tr></thead><tbody>'+
  RV.map(function(r){return '<tr><td><b>'+esc(r.n)+'</b><br><span style="font-size:12px;color:var(--ink-3)">'+esc(r.e)+'</span>'+(r.v?'<br><span class="verified">Verified</span>':"")+'</td><td class="stars" style="white-space:nowrap">'+"★".repeat(r.r)+"☆".repeat(5-r.r)+'</td><td style="min-width:220px">'+esc(r.t)+'</td><td>'+pill(r.s==="approved"?"confirmed":r.s==="hidden"?"hidden":"pending",r.s[0].toUpperCase()+r.s.slice(1))+'</td><td style="white-space:nowrap"><button class="btn sm primary" data-r="'+r.id+'" data-act="rap">Approve</button> <button class="btn sm ghost" data-r="'+r.id+'" data-act="rhi">Hide</button></td></tr>'}).join("")+'</tbody></table></div></div>';
}

function draw(){
  side();var m=$("#adminMain");
  var html={overview:vOverview,bookings:vBookings,orders:vOrders,menu:vMenu,reviews:vReviews}[tab]();
  m.innerHTML=html;
  $$(".dh",m).forEach(function(e){e.classList.add("rise")});
  if(tab==="overview")afterOverview();
  if(flashNo){var f=flashNo;setTimeout(function(){if(flashNo===f)flashNo=null},1300)}
}
function adv(no){
  var b=B.filter(function(x){return x.no===no})[0],n=NEXT[b.status];if(!n)return;
  if(n[0]==="confirmed"){
    var c=conflict(b);
    if(c){toast("Cannot confirm. "+b.venue.replace(" (listed)","")+" is already confirmed on "+dstr(b.date)+" for "+c.cust+".");return}
    if(b.paid<b.total*DEPOSIT)b.paid=Math.round(b.total*DEPOSIT);
    toast(b.no+" confirmed. Advance of "+pk(Math.round(b.total*DEPOSIT))+" recorded.");
  }else toast(b.no+": "+ST[n[0]]);
  b.status=n[0];flashNo=no;draw();
}
$("#adminMain").addEventListener("click",function(e){
  var t=e.target.closest("button");if(!t)return;
  if(t.dataset.tabGo){tab=t.dataset.tabGo;draw();return}
  if(t.dataset.rng){rangeN=+t.dataset.rng;$$("[data-rng]").forEach(function(x){x.setAttribute("aria-pressed",x===t)});wireChart(rangeN);drawAnim($("#revBox"));return}
  var a=t.dataset.act;
  if(a==="adv"){adv(t.dataset.b)}
  else if(a==="rej"||a==="can"){var b=B.filter(function(x){return x.no===t.dataset.b})[0];b.status=a==="rej"?"rejected":"cancelled";flashNo=b.no;toast(b.no+" "+(a==="rej"?"rejected":"cancelled")+". Reason and time saved to history.");draw()}
  else if(a==="oadv"){var o=O.filter(function(x){return x.no===t.dataset.o})[0];o.status=ONEXT[o.status][0];flashNo=o.no;toast(o.no+": "+OST[o.status]);draw()}
  else if(a==="rap"||a==="rhi"){var r=RV.filter(function(x){return x.id===+t.dataset.r})[0];r.s=a==="rap"?"approved":"hidden";renderRev();toast("Review "+r.s+(r.s==="approved"?" and now public":""));draw()}
  else if(t.dataset.dish!==undefined){
    var flat=[];CATS.forEach(function(c){c.dishes.forEach(function(d){flat.push(d)})});
    var d=flat[+t.dataset.dish];d[2]=!d[2];if(d[2]){CATS.forEach(function(c){var i=sel[c.id].indexOf(d[0]);if(i>-1)sel[c.id].splice(i,1)})}
    renderCats();buffet();syncBook();t.setAttribute("aria-checked",!d[2]);toast(d[0]+(d[2]?" marked unavailable":" available again"));
  }
});
$("#adminMain").addEventListener("input",function(e){
  if(e.target.id==="bsearch"){bq=e.target.value.toLowerCase();$("#btbody").innerHTML=bRows()}
  if(e.target.id==="bstatus"){bs=e.target.value;$("#btbody").innerHTML=bRows()}
});
function merge(){
  (window.__newBookings||[]).forEach(function(n){if(!B.some(function(b){return b.no===n.no}))B.unshift(n)});
}
window.AdminApp={
  enter:function(){merge();draw()},
  redraw:function(){if(!$("#v-admin").hidden)draw()},
  refreshNew:function(){merge();side()}
};
renderRev();side();
var h=(location.hash||"").replace("#","");show(h==="admin"?"admin":"home");
window.addEventListener("hashchange",function(){var x=(location.hash||"").replace("#","");if(x==="admin")show("admin");else if(x==="home")show("home")});
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(movePill);
})();
